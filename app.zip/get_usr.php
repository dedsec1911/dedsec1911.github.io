<?php 
 
include 'config.php';

    global $connect;
	$name  = $_GET['name'];
 
 
 $sql = "SELECT * FROM users WHERE name='".$name."' ";
 
 $r = mysqli_query($con,$sql);
 
 $res = mysqli_fetch_array($r);
 
 $result = array();
 
 array_push($result,array(
 "name"=>$res['name'],
 "username" =>$res['username'],
 "s1"=>$res['s1'],
 "s2"=>$res['s2'],
 "email"=>$res['email'],
 "phone"=>$res['phone'],
 "birthday"=>$res['birthday'],
 "permadd"=>$res['permadd'],
 "rnumber"=>$res['rnumber'],
 "hnumber"=>$res['hnumber'],
 "pyear"=>$res['pyear']
 )
 );
 
 echo json_encode(array("result"=>$result));
 
 mysqli_close($con);
 
 ?>