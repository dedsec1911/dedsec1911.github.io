<?php
require_once('config.php');

$sql = "select * from users";
 
$res = mysqli_query($con,$sql);
 
$result = array();
 
while($row = mysqli_fetch_array($res)){

array_push($result,array(
 "name"=>$res['name']
 )
 );
 
 echo json_encode(array("result"=>$result));
 
mysqli_close($con);
 
?>