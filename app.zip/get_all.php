﻿<?php 
 
include 'config.php';

    global $connect;
	$username  = $_GET['username'];
 
 
 $sql = "SELECT * FROM signup1 WHERE username='".$username."' ";
 
 $r = mysqli_query($con,$sql);
 
 $res = mysqli_fetch_array($r);
 
 $result = array();
 
 array_push($result,array(
 "name"=>$res['name'],
 "phone" =>$res['phone'],
 "email" =>$res['email']
 )
 );
 
 echo json_encode(array("result"=>$result));
 
 mysqli_close($con);
 
 ?>