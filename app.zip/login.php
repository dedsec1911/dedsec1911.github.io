<?php
 if($_SERVER['REQUEST_METHOD']=='POST'){
 $email = $_POST['email'];
 $password = $_POST['password'];
 
 require_once('config.php');
 
 $sql = "select * from users where email='$email' and password='$password'";
 
 $check = mysqli_fetch_array(mysqli_query($con,$sql));
 
 if(isset($check)){
 echo "success";
 }
 else{
 echo "Invalid Email or Password";
 }
 
 }else{
 echo "Check Your Connection";
 }
 ?>