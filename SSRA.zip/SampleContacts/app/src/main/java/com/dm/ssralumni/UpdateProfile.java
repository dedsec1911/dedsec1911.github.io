package com.dm.ssralumni;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;

/**
 * Created by DEDS3C on 6/28/2019.
 */

public class UpdateProfile extends AppCompatActivity {

    //private static final String LOGIN_URL = "http://ssralumni.discretemicros.in/app/login.php";
    //private static final String LOGIN_URL = "http://192.168.1.102:8082/app/login.php";
    String UPDATE_URL = "http://ssralumni.discretemicros.in/app/update.php";
    public static final String EMAIL = "email";

    Button buttonv;
    Bundle bundle;

    String query;
    private EditText tvname, tvprof, tvemail, tvphn, tvbird, tvpadd, tvrnum, tvhnum, tvpyer;
    //String username1,password1,s11,s21,email1,phone1,birthday1,permadd1,rnumber1,hnumber1,pyear1;
    String email1;
    String name  = "";
    String username =  "";
    //String s1  = "";
    //String s2  = "";
    String email = "";
    String phone  = "";
    String birthday  = "";
    String permadd  = "";
    String rnumber  = "";
    String hnumber  = "";
    String pyear  = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_profile);
        Intent intent = getIntent();
        email1 = intent.getStringExtra(Welcome.EMAIL);
        bundle = intent.getExtras();
        getData();

        tvname = findViewById(R.id.etname1);
        tvphn = findViewById(R.id.etphone);
        tvbird = findViewById(R.id.etbirdy);
        tvemail = findViewById(R.id.etemail);
        tvpadd = findViewById(R.id.etpadr);
        tvrnum = findViewById(R.id.etrnum);
        tvhnum = findViewById(R.id.ethnum);
        tvpyer = findViewById(R.id.etpyer);
        tvprof = findViewById(R.id.etprof);
        buttonv = findViewById(R.id.updbtn);

        buttonv.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v) {


                updatepro(name,username,email,phone,birthday,permadd,hnumber,rnumber,pyear);

            }

        });


    }

        private void getData() {

        try {

            query = URLEncoder.encode(EMAIL, "utf-8");

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        String url = "http://ssralumni.discretemicros.in/app/get_usr2.php?email=" + email1;
        StringRequest stringRequest = new StringRequest(url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                showJSON(response);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(UpdateProfile.this, error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        com.android.volley.RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void showJSON(String response) {

        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONArray result = jsonObject.getJSONArray(Config.JSON_ARRAY);

            JSONObject json = result.getJSONObject(0);

            name = json.getString(Config.KEY_NAME);
            username = json.getString(Config.KEY_USR);
            //s1 = json.getString(Config.KEY_S1);
            //s2 = json.getString(Config.KEY_S2);
            email = json.getString(Config.KEY_EMAIL);
            phone = json.getString(Config.KEY_PHN);
            birthday = json.getString(Config.KEY_BDAY);
            permadd = json.getString(Config.KEY_PADD);
            rnumber = json.getString(Config.KEY_RNUM);
            hnumber = json.getString(Config.KEY_HNUM);
            pyear = json.getString(Config.KEY_PYER);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        tvname.setText(name);
        tvprof.setText(username);
        //tvprof.setText(s1 + "/" + s2);
        tvemail.setText(email);
        tvphn.setText(phone);
        tvbird.setText(birthday);
        tvpadd.setText(permadd);
        tvrnum.setText(rnumber);
        tvhnum.setText(hnumber);
        tvpyer.setText(pyear);

    }

    private void updatepro(final String name, final String username, final String email, final String phone, final String birthday, final String permadd, final String hnumber, final String rnumber, final String pyear) {
        class update extends AsyncTask<String, Void, String> {

            ProgressDialog loading;
            Json ruc = new Json();

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                loading = ProgressDialog.show(UpdateProfile.this, "Updating...", "Please Wait...", false, false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                //Toast.makeText(UpdateProfile.this, s, Toast.LENGTH_LONG).show();

            }

            @Override
            protected String doInBackground(String... params) {

                //tvname.getText().toString().trim();

                HashMap<String, String> data = new HashMap<String, String>();

                data.put("name", tvname.getText().toString());
                data.put("username", tvprof.getText().toString());
                data.put("email", tvemail.getText().toString());
                data.put("phone", tvphn.getText().toString());
                data.put("birthday", tvbird.getText().toString());
                data.put("permadd", tvpadd.getText().toString());
                data.put("hnumber", tvhnum.getText().toString());
                data.put("rnumber", tvrnum.getText().toString());
                data.put("pyear", tvpyer.getText().toString());
                String s = ruc.sendPostRequest(UPDATE_URL, data);
                Log.i("Update data ", data.toString());
                return s;
            }
        }
        update de = new update();
        de.execute(name,username,email,phone,birthday,permadd,hnumber,rnumber,pyear);
        //Log.i("Updating result", name);

        // Intent intent = new Intent(RemoveTeacher.this,AddRemove.class);
        //startActivity(intent);

    }
}
