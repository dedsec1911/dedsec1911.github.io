package com.dm.ssralumni;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by DEDS3C on 6/4/2019.
 */

public class SearchContact extends AppCompatActivity {

    ListView SubjectListView;
    String ServerURL = "http://ssralumni.discretemicros.in/app/contacts.php";
    EditText editText ;
    List<String> listString = new ArrayList<String>();
    ArrayAdapter<String> arrayAdapter ;
    ProgressDialog loader;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view);
        SubjectListView = findViewById(R.id.lstview);
        editText = findViewById(R.id.inputSearch);

        new GetHttpResponse(SearchContact.this).execute();

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                SearchContact.this.arrayAdapter.getFilter().filter(charSequence);
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }

    private class GetHttpResponse extends AsyncTask<Void, Void, Void>
    {
        public Context context;
        String ResultHolder;

        public GetHttpResponse(Context context)
        {
            this.context = context;
        }
        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            loader = ProgressDialog.show(SearchContact.this, "Please Wait", "Retrieving Contacts...", true, true);
            loader.setCancelable(false);
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {
            HttpServicesClass httpServiceObject = new HttpServicesClass(ServerURL);
            try
            {
                httpServiceObject.ExecutePostRequest();

                if(httpServiceObject.getResponseCode() == 200)
                {
                    ResultHolder = httpServiceObject.getResponse();

                    if(ResultHolder != null)
                    {
                        JSONArray jsonArray = null;
                        listString.clear();

                        try {
                            jsonArray = new JSONArray(ResultHolder);
                            JSONObject jsonObject;
                            for(int i=0; i<jsonArray.length(); i++)
                            {
                                jsonObject = jsonArray.getJSONObject(i);
                                listString.add(jsonObject.getString("name"));
                                SubjectListView.setOnItemClickListener(new SearchContact.Itemlist());
                            }
                        }
                        catch (JSONException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                            Log.i("Exception",e.toString());
                        }
                    }
                }
                else
                {
                    Toast.makeText(context, httpServiceObject.getErrorMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            catch (Exception e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.i("Exception",e.toString());
            }
            return null;
        }



        @Override
        protected void onPostExecute(Void result)

        {
            loader.dismiss();
            SubjectListView.setVisibility(View.VISIBLE);
            SubjectListView.setEmptyView(findViewById(R.id.empty));
            arrayAdapter = new ArrayAdapter<String>(SearchContact.this, R.layout.list_items, R.id.tv_name, listString);
            SubjectListView.setAdapter(arrayAdapter);

        }
    }

    public class Itemlist implements AdapterView.OnItemClickListener {


        @Override
        public void onItemClick(final AdapterView<?> adapterView, View view, int i, long l) {


            new AlertDialog.Builder(SearchContact.this)
                    .setTitle(" Hold Up!")
                    .setMessage(R.string.err_mg1)
                    .setPositiveButton("Lets Go!", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            //startActivity(new Intent(SearchContact.this, MainActivity.class));
                            SearchContact.this.finish();
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            // do nothing
                        }
                    })
                    .setIcon(R.mipmap.warning)
                    .show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_ref:
                new GetHttpResponse(this).execute();
                //listString.clear();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}



