package com.dm.ssralumni;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import java.util.HashMap;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button login;
    private TextView register;
    private TextView search;
    private EditText etu, etP;
    private Session session;

    public static final String USER_NAME = "USER_NAME";
    //private static final String LOGIN_URL = "http://ssralumni.discretemicros.in/app/login.php";
    private static final String LOGIN_URL = "http://172.20.10.7:8082/app/login.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = findViewById(R.id.log);
        session = new Session(this);
        register = findViewById(R.id.reg1);
        search = findViewById(R.id.textView2);
        etu = findViewById(R.id.et1);
        etP = findViewById(R.id.et2);
        login.setOnClickListener(this);
        register.setOnClickListener(this);
        search.setOnClickListener(this);

        if (session.loggedin()) {
            startActivity(new Intent(MainActivity.this, Welcome.class));
            finish();
        }

        /*TextView textView = findViewById(R.id.textView3);
        textView.setClickable(true);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        String text = "<a href='http://www.google.com'> Google </a>";
        textView.setText(Html.fromHtml(text));*/
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.log:
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                android.net.NetworkInfo wifi = cm
                        .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                android.net.NetworkInfo datac = cm
                        .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

                if ((wifi != null & datac != null)
                        && (wifi.isConnected() | datac.isConnected())) {
                    login();


                } else {
                    //no connection
                    // Toast toast = Toast.makeText(Login.this, "No Internet Connection", Toast.LENGTH_LONG);
                    // toast.show();

                    View view = findViewById(android.R.id.content);
                    Snackbar.make(view, R.string.no_net, Snackbar.LENGTH_LONG).show();
                }

                break;
            case R.id.reg1:
                startActivity(new Intent(MainActivity.this, Signup.class));
                break;

            case R.id.textView2:
                startActivity(new Intent(MainActivity.this, SearchContact.class));
                break;

            default:

        }
    }


    private void login() {
        String email = etu.getText().toString().trim();
        String password = etP.getText().toString().trim();

        if (email.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, R.string.pls_fill, Snackbar.LENGTH_LONG).show();
        } else if (password.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, R.string.pls_fill, Snackbar.LENGTH_LONG).show();
        } else
            userLogin(email, password);
    }

    private void userLogin(final String email, final String password) {
        class UserLoginClass extends AsyncTask<String, Void, String> {
            ProgressDialog loading;


            @Override
            protected void onPreExecute() {

                super.onPreExecute();

                loading = ProgressDialog.show(MainActivity.this, "Authenticating...", "Please wait...", true);
                loading.setCancelable(false);


            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();


                if (s.equalsIgnoreCase("success")) {

                    session.setLoggedin(true);

                    Intent intent = new Intent(MainActivity.this, Welcome.class);
                    intent.putExtra(USER_NAME, email);
                    startActivity(intent);
                    finish();
                    //Toast.makeText(Login.this, "Welcome back!", Toast.LENGTH_LONG).show();

                } else {
                    View view = findViewById(android.R.id.content);
                    Snackbar.make(view, R.string.invalid, Snackbar.LENGTH_LONG).show();
                }

            }

            @Override
            protected String doInBackground(String... params) {
                HashMap<String, String> data = new HashMap<String, String>();
                data.put("email", params[0]);
                data.put("password", params[1]);

                Json ruc = new Json();

                String result = ruc.sendPostRequest(LOGIN_URL, data);

                return result;
            }
        }
        UserLoginClass ulc = new UserLoginClass();
        ulc.execute(email, password);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //finish();
    }
}
