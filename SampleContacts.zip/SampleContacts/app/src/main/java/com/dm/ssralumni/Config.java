package com.dm.ssralumni;



public class Config {
  //  public static final String DATA_URL = "http://nullify.hol.es/update.php?username=";

    public static final String KEY_NAME = "name";
    public static final String KEY_USR = "username";
    public static final String KEY_PHN = "phone";
    public static final String KEY_EMAIL = "email";
    public static final String  KEY_S1 = "s1";
    public static final String  KEY_S2 = "s2";
    public static final String  KEY_BDAY = "birthday";
    public static final String  KEY_PADD= "permadd";
    public static final String  KEY_RNUM = "rnumber";
    public static final String  KEY_HNUM = "hnumber";
    public static final String KEY_PYER = "pyear";
    public static final String JSON_ARRAY = "result";
}
