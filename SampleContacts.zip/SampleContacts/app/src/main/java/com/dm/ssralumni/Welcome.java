package com.dm.ssralumni;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by DEDS3C on 5/18/2019.
 */

public class Welcome extends AppCompatActivity{

    public static final String NAME = "name";
    String name;

    private Session session;
    ListView SubjectListView;
    String ServerURL = "http://ssralumni.discretemicros.in/app/contacts.php";
    EditText editText ;
    List<String> listString = new ArrayList<String>();
    ArrayAdapter<String> arrayAdapter ;
    ProgressDialog loader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in);
        SubjectListView = findViewById(R.id.lstview1);
        editText = findViewById(R.id.inputSearch1);

        session = new Session(this);
        if(!session.loggedin()){
            logout();
        }

        new Welcome.GetHttpResponse(Welcome.this).execute();

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                Welcome.this.arrayAdapter.getFilter().filter(charSequence);
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void logout(){
        session.setLoggedin(false);
        finish();
        startActivity(new Intent(Welcome.this,MainActivity.class));
    }


    private class GetHttpResponse extends AsyncTask<Void, Void, Void>
    {
        public Context context;
        String ResultHolder;

        public GetHttpResponse(Context context)
        {
            this.context = context;
        }
        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            loader = ProgressDialog.show(Welcome.this, "Please Wait", "Retrieving Contacts...", true, true);
            loader.setCancelable(false);
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {
            HttpServicesClass httpServiceObject = new HttpServicesClass(ServerURL);
            try
            {
                httpServiceObject.ExecutePostRequest();

                if(httpServiceObject.getResponseCode() == 200)
                {
                    ResultHolder = httpServiceObject.getResponse();

                    if(ResultHolder != null)
                    {
                        JSONArray jsonArray = null;
                        listString.clear();

                        try {
                            jsonArray = new JSONArray(ResultHolder);
                            JSONObject jsonObject;
                            for(int i=0; i<jsonArray.length(); i++)
                            {
                                jsonObject = jsonArray.getJSONObject(i);
                                listString.add(jsonObject.getString("name"));
                                SubjectListView.setOnItemClickListener(new Welcome.Itemlist());
                            }
                        }
                        catch (JSONException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                            Log.i("Exception",e.toString());
                        }
                    }
                }
                else
                {
                    Toast.makeText(context, httpServiceObject.getErrorMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            catch (Exception e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.i("Exception",e.toString());
            }
            return null;
        }



        @Override
        protected void onPostExecute(Void result)

        {
            loader.dismiss();
            SubjectListView.setVisibility(View.VISIBLE);
            SubjectListView.setEmptyView(findViewById(R.id.empty));
            arrayAdapter = new ArrayAdapter<String>(Welcome.this, R.layout.list_items, R.id.tv_name, listString);
            SubjectListView.setAdapter(arrayAdapter);

        }
    }

    public class Itemlist implements AdapterView.OnItemClickListener {


        @Override
        public void onItemClick(final AdapterView<?> adapterView, View view, int i, long l) {

            ViewGroup vg = (ViewGroup) view;

            final TextView nm = vg.findViewById(R.id.tv_name);

            name = nm.getText().toString();

            Intent intent = new Intent(Welcome.this, DetailActivity.class);
            intent.putExtra(NAME,name);
            startActivity(intent);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main2, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_logout:
                logout();
                break;
            case R.id.action_ref:
                new Welcome.GetHttpResponse(this).execute();
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}
