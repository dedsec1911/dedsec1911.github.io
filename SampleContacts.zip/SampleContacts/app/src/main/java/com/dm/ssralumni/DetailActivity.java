package com.dm.ssralumni;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * Created by DEDS3C on 6/11/2019.
 */

public class DetailActivity extends AppCompatActivity {

        String query;
        private TextView tvname, tvprof, tvemail, tvphn, tvbird, tvpadd, tvrnum, tvhnum, tvpyer;
        Bundle bundle;
        String name  = "";
        String username =  "";
        String s1  = "";
        String s2  = "";
        String email  = "";
        String phone  = "";
        String birthday  = "";
        String permadd  = "";
        String rnumber  = "";
        String hnumber  = "";
        String pyear  = "";


    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.detail_activity);
            Intent intent = getIntent();
            name = intent.getStringExtra(Welcome.NAME);
            bundle = intent.getExtras();
            getData();

            tvname = findViewById(R.id.name1);
            tvphn = findViewById(R.id.phoneeee);
            tvbird = findViewById(R.id.birdyyyy);
            tvemail = findViewById(R.id.emailll);
            tvpadd = findViewById(R.id.padrrrrr);
            tvrnum = findViewById(R.id.rnumm);
            tvhnum = findViewById(R.id.hnumm);
            tvpyer = findViewById(R.id.pyerrr);
            tvprof = findViewById(R.id.profff);

        }


        private void getData() {

            try {

                query = URLEncoder.encode(name, "utf-8");

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            String url = "http://ssralumni.discretemicros.in/app/get_usr.php?name=" + query;
            StringRequest stringRequest = new StringRequest(url, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {

                    showJSON(response);
                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(DetailActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });

            com.android.volley.RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }

        private void showJSON(String response) {

            try {
                JSONObject jsonObject = new JSONObject(response);
                JSONArray result = jsonObject.getJSONArray(Config.JSON_ARRAY);

                JSONObject json = result.getJSONObject(0);

                name = json.getString(Config.KEY_NAME);
                username = json.getString(Config.KEY_USR);
                s1 = json.getString(Config.KEY_S1);
                s2 = json.getString(Config.KEY_S2);
                email = json.getString(Config.KEY_EMAIL);
                phone = json.getString(Config.KEY_PHN);
                birthday = json.getString(Config.KEY_BDAY);
                permadd = json.getString(Config.KEY_PADD);
                rnumber = json.getString(Config.KEY_RNUM);
                hnumber = json.getString(Config.KEY_HNUM);
                pyear = json.getString(Config.KEY_PYER);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            tvname.setText(name + " " + username);
            tvprof.setText(s1 + "/" + s2);
            tvemail.setText(email);
            tvphn.setText(phone);
            tvbird.setText(birthday);
            tvpadd.setText(permadd);
            tvrnum.setText(rnumber);
            tvhnum.setText(hnumber);
            tvpyer.setText(pyear);

        }

    }
