package com.dm.ssralumni;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import android.support.design.widget.Snackbar;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;


/**
 * Created by DEDS3C on 5/18/2019.
 * Do Server URL Short
 */

public class Signup extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    //String REGISTER_URL = "http://ssralumni.discretemicros.in/app/register.php";
    String REGISTER_URL = "http://172.20.10.7:8082/app/register.php";

    private static final int PERMISSION_REQUEST_CODE = 200;

    ImageView imageView;
    Button register;
    EditText naam, unaam, pw, email1, phone1, bd, pd, rn, ho, ps;
    private DatePickerDialog datePickerDialog;
    private RadioGroup radgrp;
    Spinner s1, s2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);



        imageView = findViewById(R.id.imageView);
        register = findViewById(R.id.reg);
        naam = findViewById(R.id.name);
        unaam = findViewById(R.id.uname);
        pw = findViewById(R.id.pass);
        email1 = findViewById(R.id.email);
        phone1 = findViewById(R.id.phone);
        bd = findViewById(R.id.birday);
        pd = findViewById(R.id.padr);
        rn = findViewById(R.id.rnum);
        ho = findViewById(R.id.house);
        ps = findViewById(R.id.passyr);
        radgrp = findViewById(R.id.grg);
        s1 = findViewById(R.id.spin1);
        s2 = findViewById(R.id.spin2);
        s1.setOnItemSelectedListener(this);
        prepareDatePickerDialog();
        checkPermission();
        requestPermission();

        register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                android.net.NetworkInfo wifi = cm
                        .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                android.net.NetworkInfo datac = cm
                        .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

                if ((wifi != null & datac != null)
                        && (wifi.isConnected() | datac.isConnected())) {

                    registerUser();
                    //uploadImage();


                } else {
                    //no connection
                    //Toast toast = Toast.makeText(Signup.this, "No Internet Connection!", Toast.LENGTH_LONG);
                    //toast.show();

                    View view = findViewById(android.R.id.content);
                    Snackbar.make(view, "No Internet Connection", Snackbar.LENGTH_LONG).show();
                }
                //startActivity(new Intent(fourth.this,fifth.class));

            }

        });

        bd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                datePickerDialog.show();

            }

        });

        /*imageView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                //showFileChooser();
                Intent nextActi = new Intent(Signup.this, ImageUpload.class);
                nextActi.putExtra("NAME", naam.toString());
                startActivity(nextActi);

            }
        });*/
    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);

        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {

        ActivityCompat.requestPermissions(this, new String[]{READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0) {

                    boolean locationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean cameraAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if (locationAccepted && cameraAccepted){
                        //View view = findViewById(android.R.id.content);
                        //Snackbar.make(view, "Permission Granted!", Snackbar.LENGTH_LONG).show();
                    }

                    else {
                        //View view = findViewById(android.R.id.content);
                        //Snackbar.make(view, "Permission Denied!", Snackbar.LENGTH_LONG).show();

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (shouldShowRequestPermissionRationale(ACCESS_FINE_LOCATION)) {
                                showMessageOKCancel("You need to allow access to both the permissions",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                    requestPermissions(new String[]{ACCESS_FINE_LOCATION, CAMERA},
                                                            PERMISSION_REQUEST_CODE);
                                                }
                                            }
                                        });
                                return;
                            }
                        }

                    }
                }


                break;
        }
    }


    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(Signup.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
                               long arg3) {
        // TODO Auto-generated method stub
        String sp1 = String.valueOf(s1.getSelectedItem());
        //Toast.makeText(this, sp1, Toast.LENGTH_SHORT).show();
        if (sp1.contentEquals("Doctor")) {
            List<String> list = new ArrayList<String>();
            list.add("Dentist");
            list.add("Surgeon");
            list.add("Psychiatrist");
            list.add("Physiologist");
            list.add("Neurologist");
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_dropdown_item, list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dataAdapter.notifyDataSetChanged();
            s2.setAdapter(dataAdapter);
        }
        if (sp1.contentEquals("Engineer")) {
            List<String> list = new ArrayList<String>();
            list.add("Civil");
            list.add("Electrical");
            list.add("IT");
            list.add("Aerospace");
            list.add("Chemical");
            list.add("Biomedical");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_dropdown_item, list);
            dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }
        if (sp1.contentEquals("None")) {
            List<String> list = new ArrayList<String>();
            list.add("None");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_dropdown_item, list);
            dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    private void prepareDatePickerDialog() {
        //Get current date
        Calendar calendar = Calendar.getInstance();

        //Create datePickerDialog with initial date which is current and decide what happens when a date is selected.
        datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                //When a date is selected, it comes here.
                //Change birthdayEdittext's text and dismiss dialog.
                bd.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                datePickerDialog.dismiss();
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
    }


    private void registerUser() {
        String name = naam.getText().toString().trim();
        String username = unaam.getText().toString().trim();
        String password = pw.getText().toString().trim();
        String email = email1.getText().toString().trim().toLowerCase();
        String phone = phone1.getText().toString().trim().toLowerCase();
        String birthday = bd.getText().toString();
        String permadd = pd.getText().toString().trim().toLowerCase();
        String rnumber = rn.getText().toString().trim().toLowerCase();
        String hnumber = ho.getText().toString().trim().toLowerCase();
        String pyear = ps.getText().toString().trim().toLowerCase();

        Spinner sp1 = findViewById(R.id.spin1);
        Spinner sp2 = findViewById(R.id.spin2);
        String s2 = sp2.getSelectedItem().toString();
        String s1 = sp1.getSelectedItem().toString();


        RadioButton selectedRadioButton = findViewById(radgrp.getCheckedRadioButtonId());
        String gender = selectedRadioButton == null ? "" : selectedRadioButton.getText().toString();


        if (name.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, "Please Enter your Name", Snackbar.LENGTH_LONG).show();
        }
        //else if(!name.matches("[abcdefghijklmnopqrstuvwxyz]")){
        //naam.setError("Name should only contains Alphabets!");}

        else if (username.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, "Please Enter your Username", Snackbar.LENGTH_LONG).show();
        } else if (password.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, "Please Enter your Password", Snackbar.LENGTH_LONG).show();
        } else if (email.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, "Please Enter your Email", Snackbar.LENGTH_LONG).show();
        } else if (phone.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, "Please Enter your Phone", Snackbar.LENGTH_LONG).show();
        } else if (password.length() < 5) {
            pw.setError("Password is too Short!");
            pw.requestFocus();
            //View view = findViewById(android.R.id.content);
            //Snackbar.make(view,"Password is too Short!",Snackbar.LENGTH_LONG).show();
        } else if (!email.matches("[a-zA-Z0-9._-]+@+[gmail,yahoo,outlook,icloud,hotmail]+.+[com,org,net,in,co.in]")) {
            email1.setError("Invalid Email Address");
            email1.requestFocus();
        } else if (phone.length() < 10 || phone.length() > 10) {
            phone1.setError("Invalid Phone Number");
            phone1.requestFocus();
            //View view = findViewById(android.R.id.content);
            //Snackbar.make(view,"Please Enter valid phone number!",Snackbar.LENGTH_LONG).show();
        } else if (birthday.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, "Please Input Birth date", Snackbar.LENGTH_LONG).show();
        } else if (permadd.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, "Please Enter your Address", Snackbar.LENGTH_LONG).show();
        } else if (rnumber.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, "Please Enter your Rollnumber", Snackbar.LENGTH_LONG).show();
        } else if (hnumber.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, "Please Enter your House number", Snackbar.LENGTH_LONG).show();
        } else if (pyear.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, "Please Enter your Passing Year", Snackbar.LENGTH_LONG).show();
        } else if (gender.equals("")) {
            View view = findViewById(android.R.id.content);
            Snackbar.make(view, "Please Select Gender", Snackbar.LENGTH_LONG).show();
        } else
            register(name, username, password, email, phone, birthday, permadd, rnumber, hnumber, pyear, gender, s2, s1);
    }

    private void register(final String name, final String username, final String password, final String email, final String phone, final String birthday, final String permadd, final String rnumber, final String hnumber, final String pyear, final String gender, final String s2, final String s1) {

        class RegisterUser extends AsyncTask<String, Void, String> {
            ProgressDialog loading;
            Json ruc = new Json();


            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                String name = naam.getText().toString().trim();
                String username = unaam.getText().toString().trim();
                String password = pw.getText().toString().trim();
                String email = email1.getText().toString().trim();
                String phone = phone1.getText().toString().trim();
                String birthday = bd.getText().toString();
                String permadd = pd.getText().toString().trim();
                String rnumber = rn.getText().toString().trim();
                String hnumber = ho.getText().toString().trim();
                String pyear = ps.getText().toString().trim();

                Spinner sp1 = findViewById(R.id.spin1);
                Spinner sp2 = findViewById(R.id.spin2);
                String s2 = sp2.getSelectedItem().toString();
                String s1 = sp1.getSelectedItem().toString();

                RadioButton selectedRadioButton = findViewById(radgrp.getCheckedRadioButtonId());
                String gender = selectedRadioButton == null ? "" : selectedRadioButton.getText().toString();


                if (name.equals("") && username.equals("") && password.equals("") && email.equals("") && phone.equals("") && birthday.equals("") && permadd.equals("") && rnumber.equals("") && hnumber.equals("") && pyear.equals("") && gender.equals("") && s2.equals("") && s1.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please fill all values", Toast.LENGTH_LONG).show();
                }


                loading = ProgressDialog.show(Signup.this, "Please Wait", "Processing...", true, true);
                loading.setCancelable(false);

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();


                if (s.equalsIgnoreCase("success") || s.equals("Details already exists")) {
                    //Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
                    onPause();
                } else{
                    Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
                    //Intent intent = new Intent(Signup.this, MainActivity.class);
                    //startActivity(intent);
                     finish();
                }
            }


            @Override
            protected String doInBackground(String... params) {

                HashMap<String, String> data = new HashMap<String, String>();
                //data.put("name",params[1]);

                data.put("name", params[0]);
                data.put("username", params[1]);
                data.put("password", params[2]);
                data.put("email", params[3]);
                data.put("phone", params[4]);
                data.put("birthday", params[5]);
                data.put("permadd", params[6]);
                data.put("rnumber", params[7]);
                data.put("hnumber", params[8]);
                data.put("pyear", params[9]);
                data.put("gender", params[10]);
                data.put("s1",params[11]);
                data.put("s2",params[12]);

                String result = ruc.sendPostRequest(REGISTER_URL, data);

                Log.d("THESEARELOGS", data.toString());

                return result;
            }
        }


        RegisterUser ru = new RegisterUser();
        ru.execute(name, username, password, email, phone, birthday, permadd, rnumber, hnumber, pyear, gender, s2, s1);

    }


    @Override
    public void onBackPressed() {

        new AlertDialog.Builder(Signup.this)
                .setTitle(" Are you Sure!")
                .setMessage(R.string.back_press)
                .setPositiveButton("Yup", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        //After finishing this activity start the below one to avoid exitting app!!
                        //Intent intent = new Intent(Signup.this, MainActivity.class);
                        //startActivity(intent);
                    }
                })
                .setNegativeButton("No, Stay", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do nothing
                    }
                })
                .setIcon(R.mipmap.warning)
                .show();

    }

}
