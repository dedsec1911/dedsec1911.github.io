<?php 
echo $_SERVER["DOCUMENT_ROOT"];  
include_once("config.php"); $query="SELECT * FROM ssralumni";
$result= mysqli_query($con, $query); //create an array 
$emparray = array(); if(mysqli_num_rows($result) > 0){
while ($row = mysqli_fetch_assoc($result)) {
$emparray[] = $row;
}
}
echo json_encode(array( “status” => “true”,”message” => “Data fetched successfully!”,”data” => $emparray) );
?>