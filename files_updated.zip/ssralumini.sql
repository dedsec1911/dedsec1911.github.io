-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2019 at 02:39 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ssralumini`
--

-- --------------------------------------------------------

--
-- Table structure for table `ssralumini`
--

CREATE TABLE `ssralumini` (
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `phone` text COLLATE utf8_unicode_ci NOT NULL,
  `birthday` text COLLATE utf8_unicode_ci NOT NULL,
  `permadd` text COLLATE utf8_unicode_ci NOT NULL,
  `rnumber` text COLLATE utf8_unicode_ci NOT NULL,
  `hnumber` text COLLATE utf8_unicode_ci NOT NULL,
  `pyear` text COLLATE utf8_unicode_ci NOT NULL,
  `gender` text COLLATE utf8_unicode_ci NOT NULL,
  `s1` text COLLATE utf8_unicode_ci NOT NULL,
  `s2` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ssralumini`
--

INSERT INTO `ssralumini` (`name`, `username`, `password`, `email`, `phone`, `birthday`, `permadd`, `rnumber`, `hnumber`, `pyear`, `gender`, `s1`, `s2`) VALUES
('Dfdsf', 'Jkllkj', '888golu@888', 'lkj@gmail.com', '7878787878', '9/6/2019', '89798', '987987', '89798', '987', 'Male', 'IT', 'Engineer'),
('Harshul', 'Vishwakarma', '888golu@888', 'har@gmail.com', '7771090500', '9/6/2019', 'marathalli', '0226', 'livesta', '1995', 'Male', 'IT', 'Engineer'),
('Harsh', 'Vishwa', '888golu@888', 'harsh1@gmail.com', '7001090500', '9/6/2019', 'none', '789', 'none', '7899', 'Male', 'Electrical', 'Engineer'),
('Harsh123', 'Vishwa123', '888golu@888', 'harsh21@gmail.com', '7001090500', '9/6/2019', 'none', '789', 'none', '7899', 'Male', 'Aerospace', 'Engineer'),
('lets', 'go', '123456', 'jah@gmail.com', '1234567890', '31/01/1995', 'nope', '123', '225', '1995r', 'Male', '$Engineer', 'IT'),
('Anuj', 'Choubey', '', 'anuj@gmail.com', '7878787878', '11/6/2019', 'marathalli', '123', '226', '22336', 'Male', 'Electrical', 'Engineer'),
('Test', 'Test', '', 'test@gmail.com', '1234567890', '11/6/2019', 'banglore', '0226', 'livesta', '1995', 'Male', 'IT', 'Engineer');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
