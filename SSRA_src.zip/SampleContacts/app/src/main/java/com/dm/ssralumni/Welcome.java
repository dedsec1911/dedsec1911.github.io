package com.dm.ssralumni;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.androidadvance.topsnackbar.TSnackbar;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by DEDS3C on 5/18/2019.
 */

public class Welcome extends AppCompatActivity{

    public static final String NAME = "name";
    public static final String ID = "id";
    static String Message_send = "myname" ;
    String idn, email2, query, name2, id2;
    TextView tvname,tvids;
    Bundle bundle;

    EditText editText ;
    String myJSON;
    JSONArray persons = null;
    ArrayList<HashMap<String, String>> personList;
    ListView list;

    private static final String TAG_RESULTS = "result";
    private static final String TAG_NAME = "name";
    private static final String TAG_RON = "rnumber";
    private  static final String TAG_USR = "username";
    private  static final String TAG_PER = "pyear";
    private static final String TAG_ID = "id";

    private SimpleAdapter simpleAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in);
        LocalBroadcastManager.getInstance(this).registerReceiver(mReceiver, new IntentFilter("INTENT_NAME"));
        list = findViewById(R.id.lstview1);
        personList = new ArrayList<HashMap<String, String>>();
        editText = findViewById(R.id.inputSearch1);
        Intent intent = getIntent();
        email2 = intent.getStringExtra(MainActivity.EMAIL);
        bundle = intent.getExtras();
        getData();


        tvname = findViewById(R.id.tvnwlcm);
        tvids = findViewById(R.id.tvid);

        /*session = new Session(this);
        if(!session.loggedin()){
            logout();
        }*/

        new Welcome.GetDataJSON(Welcome.this).execute();


        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(Welcome.this);
                View mView = getLayoutInflater().inflate(R.layout.dialog_login, null);
                final EditText mBn = mView.findViewById(R.id.etSbn);
                final EditText mBln = mView.findViewById(R.id.etSbln);
                final EditText mBrn = mView.findViewById(R.id.etSbrn);
                final EditText mBpy = mView.findViewById(R.id.etSbpy);
                Button mGO = mView.findViewById(R.id.btnGo);

                mBn.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                        Welcome.this.simpleAdapter.getFilter().filter(charSequence);

                    }

                    @Override
                    public void afterTextChanged(Editable editable) {

                    }
                });

                mBln.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                        //Welcome.this.simpleAdapter.getFilter().filter(charSequence);
                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                        Welcome.this.simpleAdapter.getFilter().filter(charSequence);
                    }

                    @Override
                    public void afterTextChanged(Editable editable) {

                    }
                });

                mBrn.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                        //Welcome.this.simpleAdapter.getFilter().filter(charSequence);
                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                        Welcome.this.simpleAdapter.getFilter().filter(charSequence);
                    }

                    @Override
                    public void afterTextChanged(Editable editable) {

                    }
                });

                mBpy.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                        //Welcome.this.simpleAdapter.getFilter().filter(charSequence);
                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                        Welcome.this.simpleAdapter.getFilter().filter(charSequence);
                    }

                    @Override
                    public void afterTextChanged(Editable editable) {

                    }
                });

                mBuilder.setView(mView);
                final AlertDialog dialog = mBuilder.create();
                dialog.show();
                mGO.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
        });
    }


    /*private void logout(){
        session.setLoggedin(false);

    }*/


    protected void showList() {

        personList.clear();

        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            persons = jsonObj.getJSONArray(TAG_RESULTS);

            for (int i = 0; i < persons.length(); i++) {
                JSONObject c = persons.getJSONObject(i);
                String name = c.getString(TAG_NAME);
                String username =c.getString(TAG_USR);
                String rnumber = c.getString(TAG_RON);
                String pyear = c.getString(TAG_PER);
                String id = c.getString(TAG_ID);

                HashMap<String, String> ssr = new HashMap<String, String>();

                ssr.put(TAG_NAME, name);
                ssr.put(TAG_RON, rnumber);
                ssr.put(TAG_USR, username);
                ssr.put(TAG_PER, pyear);
                ssr.put(TAG_ID, id);

                personList.add(ssr);
            }

            this.simpleAdapter = new SimpleAdapter(
                    this, personList, R.layout.list_items, new String[]{TAG_NAME, TAG_USR, TAG_RON, TAG_PER, TAG_ID},
                    new int[]{R.id.tv_name, R.id.tv_py, R.id.tv_uname, R.id.tv_rnum, R.id.tv_id}
            );

            list.setVisibility(View.VISIBLE);
            list.setEmptyView(findViewById(R.id.empty));
            list.setAdapter(simpleAdapter);
            list.setOnItemClickListener(new Itemlist());

        } catch (JSONException e) {
            e.printStackTrace();
            Log.i("EXCEPTION_HANDLER", e.toString());
        }

    }


        private class GetDataJSON extends AsyncTask<String, Void, String> {

            public Context context;

            public GetDataJSON(Context context)
            {
                this.context = context;
            }

            private ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                loading = ProgressDialog.show(Welcome.this, "Please Wait...", "Retrieving Contacts...", true, true);
                loading.setCancelable(false);
            }

            @Override
            protected String doInBackground(String... params) {
                DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());
                HttpPost httppost = new HttpPost("http://ssralumni.discretemicros.in/app/contacts2.php");

                // Depends on your web service
                httppost.setHeader("Content-type", "application/json");

                InputStream inputStream = null;
                String result = null;
                try {
                    HttpResponse response = httpclient.execute(httppost);
                    HttpEntity entity = response.getEntity();

                    inputStream = entity.getContent();
                    // json is UTF-8 by default
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
                    StringBuilder sb = new StringBuilder();

                    String line = null;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    result = sb.toString();
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.i("EXCEPTION_HANDLER_2", e.toString());
                } finally {
                    try {
                        if (inputStream != null) inputStream.close();
                    } catch (Exception squish) {
                    }
                }
                return result;
            }

            @Override
            protected void onPostExecute(String result) {
                myJSON = result;
                showList();
                loading.dismiss();
            }

        }



    public class Itemlist implements AdapterView.OnItemClickListener {


        @Override
        public void onItemClick(final AdapterView<?> adapterView, View view, int i, long l) {

            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            android.net.NetworkInfo wifi = cm
                    .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            android.net.NetworkInfo datac = cm
                    .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

            if ((wifi != null & datac != null)
                    && (wifi.isConnected() | datac.isConnected())) {

                ViewGroup vg = (ViewGroup) view;

                final TextView tid = vg.findViewById(R.id.tv_id);

                idn = tid.getText().toString();

                Intent intent = new Intent(Welcome.this, DetailActivity.class);
                intent.putExtra(ID, idn);
                startActivity(intent);

            } else {

                TSnackbar.make(findViewById(android.R.id.content), R.string.no_net ,TSnackbar.LENGTH_LONG).show();

            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main2, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_logout:
                finish();
                startActivity(new Intent(Welcome.this, MainActivity.class));
                break;

            case R.id.action_ref:
                new Welcome.GetDataJSON(this).execute();
                break;

            case R.id.action_edit:
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                android.net.NetworkInfo wifi = cm
                        .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                android.net.NetworkInfo datac = cm
                        .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

                if ((wifi != null & datac != null)
                        && (wifi.isConnected() | datac.isConnected())) {

                    Intent intent = new Intent(Welcome.this, UpdateProfile.class);
                    String MSG = tvids.getText().toString();
                    intent.putExtra(Message_send, MSG);
                    startActivity(intent);

                    Log.i("Name data", MSG);

                } else {

                    TSnackbar.make(findViewById(android.R.id.content), R.string.no_net ,TSnackbar.LENGTH_LONG).show();

                }
                break;

            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }



    private void getData() {

        try {

            query = URLEncoder.encode(Message_send, "utf-8");

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        String url = "http://ssralumni.discretemicros.in/app/get_usr2.php?email=" + email2;
        StringRequest stringRequest = new StringRequest(url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                showJSON(response);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Welcome.this, error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        com.android.volley.RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void showJSON(String response) {

        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONArray result = jsonObject.getJSONArray(Config.JSON_ARRAY);

            JSONObject json = result.getJSONObject(0);

            name2 = json.getString(NAME);
            id2 = json.getString(ID);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        tvname.setText(name2);
        tvids.setText(id2);

        View view = findViewById(android.R.id.content);
        Snackbar.make(view,"Logged in as " + name2, Snackbar.LENGTH_LONG).show();

    }

    @Override
    public void onBackPressed() {

        new AlertDialog.Builder(Welcome.this)
                .setTitle(" Logout & Exit!")
                //.setMessage("This will redirect you to the Login page!")
                .setPositiveButton("Yup", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        moveTaskToBack(true);
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(1);

                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do nothing
                    }
                })
                .setIcon(R.mipmap.warning)
                .show();

    }

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String txt = intent.getStringExtra(UpdateProfile.send_again);
            tvname.setText(txt);
            new Welcome.GetDataJSON(Welcome.this).execute();
        }
    };

}