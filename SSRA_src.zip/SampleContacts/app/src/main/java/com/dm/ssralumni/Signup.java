package com.dm.ssralumni;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import android.support.design.widget.Snackbar;


import com.androidadvance.topsnackbar.TSnackbar;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import me.srodrigo.androidhintspinner.HintAdapter;
import me.srodrigo.androidhintspinner.HintSpinner;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;


/**
 * Created by DEDS3C on 5/18/2019.
 * Do Server URL Short
 */

public class Signup extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String REGISTER_URL = "http://ssralumni.discretemicros.in/app/register.php";
    //String REGISTER_URL = "http://172.20.10.7:8082/app/register.php";

    private static final int PERMISSION_REQUEST_CODE = 200;

    ImageView imageView;
    Button register;
    EditText naam, unaam, pw, email1, phone1, bd, pd, rn, ps, pw2, job1;
    private DatePickerDialog datePickerDialog;
    private RadioGroup radgrp;
    Spinner s1, s2, hnumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);

        imageView = findViewById(R.id.imageView);
        register = findViewById(R.id.reg);
        naam = findViewById(R.id.name);
        unaam = findViewById(R.id.uname);
        pw = findViewById(R.id.pass);
        pw2 = findViewById(R.id.pass2);
        email1 = findViewById(R.id.email);
        phone1 = findViewById(R.id.phone);
        bd = findViewById(R.id.birday);
        pd = findViewById(R.id.padr);
        rn = findViewById(R.id.rnum);
        //ho = findViewById(R.id.house);
        ps = findViewById(R.id.passyr);
        radgrp = findViewById(R.id.grg);
        s1 = findViewById(R.id.spin1);
        s2 = findViewById(R.id.spin2);
        hnumber = findViewById(R.id.house);
        job1 = findViewById(R.id.jobs);
        s1.setOnItemSelectedListener(this);
        prepareDatePickerDialog();
        checkPermission();
        requestPermission();

        register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                android.net.NetworkInfo wifi = cm
                        .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                android.net.NetworkInfo datac = cm
                        .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

                if ((wifi != null & datac != null)
                        && (wifi.isConnected() | datac.isConnected())) {

                    registerUser();
                    //uploadImage();


                } else {
                    //no connection
                    //Toast toast = Toast.makeText(Signup.this, "No Internet Connection!", Toast.LENGTH_LONG);
                    //toast.show();

                    TSnackbar.make(findViewById(android.R.id.content), R.string.no_net ,TSnackbar.LENGTH_LONG).show();

                }
                //startActivity(new Intent(fourth.this,fifth.class));

            }

        });

        bd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                datePickerDialog.show();

            }

        });

        /*imageView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                //showFileChooser();
                Intent nextActi = new Intent(Signup.this, ImageUpload.class);
                nextActi.putExtra("NAME", naam.toString());
                startActivity(nextActi);

            }
        });*/
    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);

        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {

        ActivityCompat.requestPermissions(this, new String[]{READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0) {

                    boolean locationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean cameraAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if (locationAccepted && cameraAccepted){
                        //View view = findViewById(android.R.id.content);
                        //Snackbar.make(view, "Permission Granted!", Snackbar.LENGTH_LONG).show();
                    }

                    else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (shouldShowRequestPermissionRationale(ACCESS_FINE_LOCATION)) {
                                showMessageOKCancel("You need to allow access to the permissions!",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                    requestPermissions(new String[]{ACCESS_FINE_LOCATION, CAMERA},
                                                            PERMISSION_REQUEST_CODE);
                                                }
                                            }
                                        });
                                return;
                            }
                        }

                    }
                }
                break;
        }
    }


    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(Signup.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        // TODO Auto-generated method stub
        String sp1 = String.valueOf(s1.getSelectedItem());
        //Toast.makeText(this, sp1, Toast.LENGTH_SHORT).show();
        if (sp1.contentEquals("Doctors & Related")) {
            List<String> list = new ArrayList<String>();
            list.add("General");
            list.add("Physician");
            list.add("Dentist");
            list.add("Pediatricians");
            list.add("Optometrists");
            list.add("Nurse");
            list.add("Medicine");
            list.add("Physical Therapists");
            list.add("Psychiatrists");
            list.add("Orthopedic");
            list.add("Dermatologists");
            list.add("Cardiologist");
            list.add("Neurologist");
            list.add("Radiologists");
            list.add("Surgeons");
            list.add("Urologists");
            list.add("Obstetricians and Gynecologists");
            list.add("Occupational Therapists");
            list.add("Pharmacists");
            list.add("Pathologists");
            list.add("Dietitians and Nutritionists");
            list.add("Physiotherapist");
            list.add("Others");
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                    R.layout.spinner_item, list);
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            dataAdapter.notifyDataSetChanged();
            s2.setAdapter(dataAdapter);
        }


        if (sp1.contentEquals("Engineering & Science")) {
            List<String> list = new ArrayList<String>();
            list.add("Civil");
            list.add("Architect");
            list.add("Automotive");
            list.add("IT Software");
            list.add("IT Hardware");
            list.add("Chemical");
            list.add("Mechanical");
            list.add("Electrical");
            list.add("Electronic");
            list.add("Aeronautic");
            list.add("Industrial");
            list.add("Marine");
            list.add("Petroleum");
            list.add("Environment Engineer/Scientist");
            list.add("GeoScientist/Geologist");
            list.add("Agricultural");
            list.add("Mathematicians");
            list.add("Biologist");
            list.add("Physicists");
            list.add("Archaeologists");
            list.add("Others");

            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    R.layout.spinner_item, list);
            dataAdapter2.setDropDownViewResource(R.layout.spinner_dropdown);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }


        if (sp1.contentEquals("State Government Employee")) {
            List<String> list = new ArrayList<String>();
            list.add("Elected (mayor, governor, etc.)");
            list.add("Administrative");
            list.add("Foreign service");
            list.add("Income Tax");
            list.add("PSU Banks");
            list.add("Auditors");
            list.add("PSU Industries");
            list.add(" Civil Aviation");
            list.add("Railways");
            list.add("Power Sector");
            list.add("Agriculture");
            list.add("Home Affairs");
            list.add("Law and Justice");
            list.add("Telecommunication (DOT)");
            list.add("Post Office");
            list.add("Information Technology (DIT)");
            list.add("Health And Family Welfare");
            list.add("Finance");
            list.add("Human Resource (HRD)");
            list.add("Others");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    R.layout.spinner_item, list);
            dataAdapter2.setDropDownViewResource(R.layout.spinner_dropdown);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }

        if (sp1.contentEquals("Central Government Employee")) {
            List<String> list = new ArrayList<String>();
            list.add("Elected (mayor, governor, etc.)");
            list.add("Administrative");
            list.add("Foreign service");
            list.add("Income Tax");
            list.add("PSU Banks");
            list.add("Auditors");
            list.add("PSU Industries");
            list.add("Civil Aviation");
            list.add("Railways");
            list.add("Power Sector");
            list.add("Agriculture");
            list.add("Home Affairs");
            list.add("Law and Justice");
            list.add("Telecommunication (DOT)");
            list.add("Post Office");
            list.add("Information Technology (DIT)");
            list.add("Health And Family Welfare");
            list.add("Finance");
            list.add("Human Resource (HRD)");
            list.add("Others");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    R.layout.spinner_item, list);
            dataAdapter2.setDropDownViewResource(R.layout.spinner_dropdown);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }

        if (sp1.contentEquals("Agriculture, Food and Natural Resources")) {
            List<String> list = new ArrayList<String>();
            list.add("Agricultural Equipment Operators/Technician");
            list.add("Agricultural Equipment Dealer");
            list.add("Agricultural Inspectors");
            list.add("Agricultural Scientist/Teachers");
            list.add("Veterinarians");
            list.add("Mining Engineer");
            list.add("Environmental Scientists and Technologists");
            list.add("Farm and horticulture Professional");
            list.add("Food Scientists and Technologists");
            list.add("GeologistForest Engineer");
            list.add("Nursery Worker");
            list.add("Others");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    R.layout.spinner_item, list);
            dataAdapter2.setDropDownViewResource(R.layout.spinner_dropdown);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }

        if (sp1.contentEquals("Hospitality and Tourism Careers")) {
            List<String> list = new ArrayList<String>();
            list.add("Chefs");
            list.add("Travel Agents");
            list.add("Event Management");
            list.add("Hotel Management");
            list.add("Amusement Park");
            list.add("Cruises");
            list.add("Catering");
            list.add("Others");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    R.layout.spinner_item, list);
            dataAdapter2.setDropDownViewResource(R.layout.spinner_dropdown);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }

        if (sp1.contentEquals("Law, Public Safety and Security")) {
            List<String> list = new ArrayList<String>();
            list.add("Judges, Adjudicators and Hearing Officer");
            list.add("Arbitrators, Mediators, and Conciliators");
            list.add("Lawyers");
            list.add("Police Officers/Detectives");
            list.add("Private Detectives/Investigators");
            list.add("Security Personal");
            list.add("Criminal Investigators and Special Agents");
            list.add("Criminal Justice and Law Enforcement Teachers");
            list.add("Firefighters");
            list.add("Forensic Scientist");
            list.add("Immigration and Customs Inspectors");
            list.add("Others");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    R.layout.spinner_item, list);
            dataAdapter2.setDropDownViewResource(R.layout.spinner_dropdown);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }

        if (sp1.contentEquals("Finance")) {
            List<String> list = new ArrayList<String>();
            list.add("Retail and Corporate Banking");
            list.add("Fraud Investigators");
            list.add("Insurance ");
            list.add("Loan Officer");
            list.add("Financial Adviser");
            list.add("Securities and Commodities Traders");
            list.add("Tax Consultant");
            list.add("Fund Manager");
            list.add("Financial sales officer");
            list.add("Others");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    R.layout.spinner_item, list);
            dataAdapter2.setDropDownViewResource(R.layout.spinner_dropdown);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }

        if (sp1.contentEquals("Education and Training")) {
            List<String> list = new ArrayList<String>();
            list.add("School Teachers");
            list.add("Professor");
            list.add("Librarians");
            list.add("Coaches and Scouts");
            list.add("Curators");
            list.add("Physical Trainer");
            list.add("Others");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_dropdown_item, list);
            dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }

        if (sp1.contentEquals("Marketing, Sales and Service")) {
            List<String> list = new ArrayList<String>();
            list.add("Sales Personal");
            list.add("Telemarketers");
            list.add("BPO");
            list.add("Real Estate Brokers");
            list.add("Procurement");
            list.add("Others");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    R.layout.spinner_item, list);
            dataAdapter2.setDropDownViewResource(R.layout.spinner_dropdown);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }


        if (sp1.contentEquals("Others")) {
            List<String> list = new ArrayList<String>();
            list.add("Others");
            ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,
                    R.layout.spinner_item, list);
            dataAdapter2.setDropDownViewResource(R.layout.spinner_dropdown);
            dataAdapter2.notifyDataSetChanged();
            s2.setAdapter(dataAdapter2);
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    private void prepareDatePickerDialog() {
        //Get current date
        Calendar calendar = Calendar.getInstance();

        //Create datePickerDialog with initial date which is current and decide what happens when a date is selected.
        datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                //When a date is selected, it comes here.
                //Change birthdayEdittext's text and dismiss dialog.
                bd.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                datePickerDialog.dismiss();
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
    }


    private void registerUser() {
        String name = naam.getText().toString().trim();
        String username = unaam.getText().toString().trim();
        String password = pw.getText().toString().trim();
        String psscnf = pw2.getText().toString().trim();
        String email = email1.getText().toString().trim().toLowerCase();
        String phone = phone1.getText().toString().trim();
        String birthday = bd.getText().toString();
        String permadd = pd.getText().toString().trim();
        String rnumber = rn.getText().toString().trim();
        //String hnumber = ho.getText().toString().trim().toLowerCase();
        String pyear = ps.getText().toString().trim().toLowerCase();
        String job = job1.getText().toString().trim();

        Spinner sp1 = findViewById(R.id.spin1);
        Spinner sp2 = findViewById(R.id.spin2);
        Spinner sp3 = findViewById(R.id.house);

        String hnumber = sp3.getSelectedItem().toString();

        String s2 = sp2.getSelectedItem().toString();
        String s1 = sp1.getSelectedItem().toString();

        RadioButton selectedRadioButton = findViewById(radgrp.getCheckedRadioButtonId());
        String gender = selectedRadioButton == null ? "" : selectedRadioButton.getText().toString();


        if (name.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), "Please Enter your FirstName" ,TSnackbar.LENGTH_LONG).show();
        } else if (username.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), "Please Enter your LastName" ,TSnackbar.LENGTH_LONG).show();
        } else if (password.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), "Please Enter your Password" ,TSnackbar.LENGTH_LONG).show();
        } else if (email.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), "Please Enter your Email" ,TSnackbar.LENGTH_LONG).show();
        } else if (phone.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), "Please Enter your Phone" ,TSnackbar.LENGTH_LONG).show();
        } else if (password.length() < 5 || !psscnf.matches(password)) {
            pw.setError("Password does not match!");
            pw.requestFocus();
        } else if (!isValidEmail(email)) {
            email1.setError("Invalid Email Address");
            email1.requestFocus();
        } else if (phone.length() < 10 || phone.length() > 10) {
            phone1.setError("Invalid Phone Number");
            phone1.requestFocus();
        } else if (birthday.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), "Please Input Birth date" ,TSnackbar.LENGTH_LONG).show();
        } else if (permadd.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), "Please Enter your Address" ,TSnackbar.LENGTH_LONG).show();
        } else if (rnumber.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), "Please Enter your Rollnumber" ,TSnackbar.LENGTH_LONG).show();
        } else if (pyear.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), "Please Enter your Passing Year" ,TSnackbar.LENGTH_LONG).show();
        } else if (gender.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), "Please Select Gender" ,TSnackbar.LENGTH_LONG).show();
        } else if (job.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), "Please Enter Job Details" ,TSnackbar.LENGTH_LONG).show();
        } else if (rn.length() < 4 || rn.length() > 4) {
            rn.setError("Invalid Rollnumber");
            rn.requestFocus();
        } else if (ps.length() < 4 || ps.length() > 4) {
            ps.setError("Invalid Year");
            ps.requestFocus();
        } else
            register(name, username, password, email, phone, birthday, permadd, rnumber, hnumber, pyear, gender, s2, s1, job);
    }

    private static boolean isValidEmail(String email) {
        return !TextUtils.isEmpty(email) && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void register(final String name, final String username, final String password, final String email, final String phone, final String birthday, final String permadd, final String rnumber, final String hnumber, final String pyear, final String gender, final String s2, final String s1, final String job) {

        class RegisterUser extends AsyncTask<String, Void, String> {
            ProgressDialog loading;
            Json ruc = new Json();


            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                String name = naam.getText().toString().trim();
                String username = unaam.getText().toString().trim();
                String password = pw.getText().toString().trim();
                String email = email1.getText().toString().trim();
                String phone = phone1.getText().toString().trim();
                String birthday = bd.getText().toString();
                String permadd = pd.getText().toString().trim();
                String rnumber = rn.getText().toString().trim();
                //String hnumber = ho.getText().toString().trim();
                String pyear = ps.getText().toString().trim();
                String job = job1.getText().toString().trim();

                Spinner sp1 = findViewById(R.id.spin1);
                Spinner sp2 = findViewById(R.id.spin2);
                Spinner sp3 = findViewById(R.id.house);
                String hnumber = sp3.getSelectedItem().toString();
                String s2 = sp2.getSelectedItem().toString();
                String s1 = sp1.getSelectedItem().toString();

                RadioButton selectedRadioButton = findViewById(radgrp.getCheckedRadioButtonId());
                String gender = selectedRadioButton == null ? "" : selectedRadioButton.getText().toString();


                if (name.equals("") && username.equals("") && password.equals("") && email.equals("") && phone.equals("") && birthday.equals("") && permadd.equals("") && rnumber.equals("") && hnumber.equals("") && pyear.equals("") && gender.equals("") && s2.equals("") && s1.equals("") && job.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please fill all values", Toast.LENGTH_LONG).show();
                }


                loading = ProgressDialog.show(Signup.this, "Please Wait", "Processing...", true, true);
                loading.setCancelable(false);

            }

            @Override
            protected void onPostExecute(String response) {
                super.onPostExecute(response);
                loading.dismiss();


                if (response.equalsIgnoreCase("success") || response.equals("Details already exists") || response.equals("oops! Please try again!")) {

                    Toast.makeText(getApplicationContext(),response,Toast.LENGTH_LONG).show();
                    onPause();
                    Log.i("SERVER_DATA", response);

                } else{
                    Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                    //Intent intent = new Intent(Signup.this, MainActivity.class);
                    //startActivity(intent);
                     finish();
                    Log.i("SERVER_DATA", response);
                }
            }


            @Override
            protected String doInBackground(String... params) {

                HashMap<String, String> data = new HashMap<String, String>();
                //data.put("name",params[1]);

                data.put("name", params[0]);
                data.put("username", params[1]);
                data.put("password", params[2]);
                data.put("email", params[3]);
                data.put("phone", params[4]);
                data.put("birthday", params[5]);
                data.put("permadd", params[6]);
                data.put("rnumber", params[7]);
                data.put("hnumber", params[8]);
                data.put("pyear", params[9]);
                data.put("gender", params[10]);
                data.put("s1",params[11]);
                data.put("s2",params[12]);
                data.put("job",params[13]);

                String result = ruc.sendPostRequest(REGISTER_URL, data);

                Log.d("THESEARELOGS", data.toString());

                return result;
            }
        }


        RegisterUser ru = new RegisterUser();
        ru.execute(name, username, password, email, phone, birthday, permadd, rnumber, hnumber, pyear, gender, s2, s1, job);

    }


    @Override
    public void onBackPressed() {

        new AlertDialog.Builder(Signup.this)
                .setTitle(" Are you Sure!")
                .setMessage(R.string.back_press)
                .setPositiveButton("Yup", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        finish();

                    }
                })
                .setNegativeButton("No, Stay", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        // do nothing

                    }
                })
                .setIcon(R.mipmap.warning)
                .show();

    }

}
