package com.dm.ssralumni;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.androidadvance.topsnackbar.TSnackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.HashMap;


/**
 * Created by DEDS3C on 6/28/2019.
 */

public class UpdateProfile extends AppCompatActivity {

    //private static final String LOGIN_URL = "http://ssralumni.discretemicros.in/app/login.php";
    //private static final String LOGIN_URL = "http://192.168.1.102:8082/app/login.php";
    String UPDATE_URL = "http://ssralumni.discretemicros.in/app/update.php";
    public static final String EMAIL = "email";
    public static final String NAME = "name";
    static String send_again = "myname2" ;
    private DatePickerDialog datePickerDialog;

    Button buttonv;
    String query;
    private EditText tvname, tvprof, tvemail, tvphn, tvbird, tvpadd, tvrnum, tvhnum, tvpyer, tvgend;
    TextView tvid;
    //String username1,password1,s11,s21,email1,phone1,birthday1,permadd1,rnumber1,hnumber1,pyear1;
    String id = "";
    String name  = "";
    String username =  "";
    //String s1  = "";
    //String s2  = "";
    String email = "";
    String phone  = "";
    String birthday  = "";
    String permadd  = "";
    String rnumber  = "";
    String hnumber  = "";
    String pyear  = "";
    String gender = "";
    String Show_msg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_profile);

        //tv = findViewById(R.id.msg_show);
        Intent rcv = getIntent();
        Show_msg = rcv.getStringExtra(Welcome.Message_send);
        getData();
        prepareDatePickerDialog();

        tvid = findViewById(R.id.textView11);
        tvname = findViewById(R.id.etname1);
        tvphn = findViewById(R.id.etphone);
        tvbird = findViewById(R.id.etbirdy);
        tvemail = findViewById(R.id.etemail);
        tvpadd = findViewById(R.id.etpadr);
        tvrnum = findViewById(R.id.etrnum);
        tvhnum = findViewById(R.id.ethnum);
        tvpyer = findViewById(R.id.etpyer);
        tvprof = findViewById(R.id.etprof);
        tvgend = findViewById(R.id.etgen);
        buttonv = findViewById(R.id.updbtn);

        tvbird.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                datePickerDialog.show();
            }
        });


        buttonv.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v) {

                String email1 = tvemail.getText().toString();
                String name1 = tvname.getText().toString();
                String prof1 = tvprof.getText().toString();
                String phn1 = tvphn.getText().toString();
                String bird1 = tvbird.getText().toString();
                String padd1 = tvpadd.getText().toString();
                String rnum1 = tvrnum.getText().toString();
                String hnum1 = tvhnum.getText().toString();
                String pyer1 = tvpyer.getText().toString();
                String gend1 = tvgend.getText().toString();

                if (name1.equals("")) {
                    TSnackbar.make(findViewById(android.R.id.content), "Please Enter your FirstName" ,TSnackbar.LENGTH_LONG).show();
                } else if (prof1.equals("")) {
                    TSnackbar.make(findViewById(android.R.id.content), "Please Enter your LastName" ,TSnackbar.LENGTH_LONG).show();
                }  else if (email1.equals("")) {
                    TSnackbar.make(findViewById(android.R.id.content), "Please Enter your Email" ,TSnackbar.LENGTH_LONG).show();
                } else if (phn1.equals("")) {
                    TSnackbar.make(findViewById(android.R.id.content), "Please Enter your Phone Number" ,TSnackbar.LENGTH_LONG).show();
                }  else if (!isValidEmail(email1)) {
                    tvemail.setError("Invalid Email Address");
                    tvemail.requestFocus();
                } else if (tvphn.length() < 10 || tvphn.length() > 10) {
                    tvphn.setError("Invalid Phone Number");
                    tvphn.requestFocus();
                } else if (tvrnum.length() < 4 || tvrnum.length() > 4) {
                    tvrnum.setError("Invalid Rollnumber");
                    tvrnum.requestFocus();
                } else if (tvpyer.length() < 4 || tvpyer.length() > 4) {
                    tvpyer.setError("Invalid Rollnumber");
                    tvpyer.requestFocus();
                } else if (bird1.equals("")) {
                    TSnackbar.make(findViewById(android.R.id.content), "Please Input Birth date" ,TSnackbar.LENGTH_LONG).show();
                } else if (padd1.equals("")) {
                    TSnackbar.make(findViewById(android.R.id.content), "Please Enter your Permanent Address" ,TSnackbar.LENGTH_LONG).show();
                } else if (rnum1.equals("")) {
                    TSnackbar.make(findViewById(android.R.id.content), "Please Enter your RollNumber" ,TSnackbar.LENGTH_LONG).show();
                } else if (hnum1.equals("")) {
                    TSnackbar.make(findViewById(android.R.id.content), "Please Enter your HouseName" ,TSnackbar.LENGTH_LONG).show();
                } else if (pyer1.equals("")) {
                    TSnackbar.make(findViewById(android.R.id.content), "Please Enter Passing Year" ,TSnackbar.LENGTH_LONG).show();
                } else if (gend1.equals("")) {
                    TSnackbar.make(findViewById(android.R.id.content), "Please Specify Gender" ,TSnackbar.LENGTH_LONG).show();
                }  else
                    updatepro(id,name,username,email,phone,birthday,permadd,hnumber,rnumber,pyear,gender);
            }

        });


    }

    private void prepareDatePickerDialog() {
        //Get current date
        Calendar calendar = Calendar.getInstance();

        //Create datePickerDialog with initial date which is current and decide what happens when a date is selected.
        datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                //When a date is selected, it comes here.
                //Change birthdayEdittext's text and dismiss dialog.
                tvbird.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                datePickerDialog.dismiss();
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
    }

    private static boolean isValidEmail(String email1) {
        return !TextUtils.isEmpty(email1) && android.util.Patterns.EMAIL_ADDRESS.matcher(email1).matches();
    }

        private void getData() {

        try {

            query = URLEncoder.encode(EMAIL, "utf-8");

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        String url = "http://ssralumni.discretemicros.in/app/get_user3.php?id=" + Show_msg;
        StringRequest stringRequest = new StringRequest(url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                showJSON(response);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(UpdateProfile.this, error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        com.android.volley.RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void showJSON(String response) {

        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONArray result = jsonObject.getJSONArray(Config.JSON_ARRAY);

            JSONObject json = result.getJSONObject(0);

            id = json.getString(Config.KEY_ID);
            name = json.getString(Config.KEY_NAME);
            username = json.getString(Config.KEY_USR);
            //s1 = json.getString(Config.KEY_S1);
            //s2 = json.getString(Config.KEY_S2);
            email = json.getString(Config.KEY_EMAIL);
            phone = json.getString(Config.KEY_PHN);
            birthday = json.getString(Config.KEY_BDAY);
            permadd = json.getString(Config.KEY_PADD);
            rnumber = json.getString(Config.KEY_RNUM);
            hnumber = json.getString(Config.KEY_HNUM);
            pyear = json.getString(Config.KEY_PYER);
            gender = json.getString(Config.KEY_GEND);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        tvid.setText(id);
        tvname.setText(name);
        tvprof.setText(username);
        //tvprof.setText(s1 + "/" + s2);
        tvemail.setText(email);
        tvphn.setText(phone);
        tvbird.setText(birthday);
        tvpadd.setText(permadd);
        tvrnum.setText(rnumber);
        tvhnum.setText(hnumber);
        tvpyer.setText(pyear);
        tvgend.setText(gender);

    }

    private void updatepro(final String id, final String name, final String username, final String email, final String phone, final String birthday, final String permadd, final String hnumber, final String rnumber, final String pyear, final String gender) {
        class update extends AsyncTask<String, Void, String> {

            ProgressDialog loading;
            Json ruc = new Json();

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                loading = ProgressDialog.show(UpdateProfile.this, "Updating...", "Please Wait...", false, false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(UpdateProfile.this, s, Toast.LENGTH_LONG).show();

                String txt = tvname.getText().toString();
                Intent intent = new Intent("INTENT_NAME").putExtra(send_again, txt);
                LocalBroadcastManager.getInstance(UpdateProfile.this).sendBroadcast(intent);
                finish();

            }

            @Override
            protected String doInBackground(String... params) {

                //tvname.getText().toString().trim();

                HashMap<String, String> data = new HashMap<String, String>();

                data.put("id", tvid.getText().toString());
                data.put("name", tvname.getText().toString());
                data.put("username", tvprof.getText().toString());
                data.put("email", tvemail.getText().toString());
                data.put("phone", tvphn.getText().toString());
                data.put("birthday", tvbird.getText().toString());
                data.put("permadd", tvpadd.getText().toString());
                data.put("hnumber", tvhnum.getText().toString());
                data.put("rnumber", tvrnum.getText().toString());
                data.put("pyear", tvpyer.getText().toString());
                data.put("gender", tvgend.getText().toString());
                String s = ruc.sendPostRequest(UPDATE_URL, data);
                Log.i("Update data ", data.toString());
                return s;
            }
        }
        update de = new update();
        de.execute(id,name,username,email,phone,birthday,permadd,hnumber,rnumber,pyear,gender);
        //Log.i("Updating result", name);

        // Intent intent = new Intent(RemoveTeacher.this,AddRemove.class);
        //startActivity(intent);

    }
}
