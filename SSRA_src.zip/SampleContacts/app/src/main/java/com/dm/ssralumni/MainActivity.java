package com.dm.ssralumni;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.androidadvance.topsnackbar.TSnackbar;

import java.util.HashMap;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button login;
    TextView register;
    TextView search;
    private EditText etu, etP;
    //private Session session;

    boolean doubleBackToExitPressedOnce = false;
    public static final String EMAIL = "email";
    private static final String LOGIN_URL = "http://ssralumni.discretemicros.in/app/login.php";
    //private static final String LOGIN_URL = "http://172.20.10.7:8082/app/login.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = findViewById(R.id.log);
        //session = new Session(this);
        register = findViewById(R.id.reg1);
        search = findViewById(R.id.textView2);
        etu = findViewById(R.id.et1);
        etP = findViewById(R.id.et2);
        login.setOnClickListener(this);
        register.setOnClickListener(this);
        search.setOnClickListener(this);

       /* if (session.loggedin()) {
            startActivity(new Intent(MainActivity.this, Welcome.class));
            MainActivity.this.finish();
        }*/

        TextView aboutBodyView = findViewById(R.id.textView3);
        aboutBodyView.setText(Html.fromHtml(getString(R.string.about_body)));
        aboutBodyView.setMovementMethod(new LinkMovementMethod());
        aboutBodyView.setTextColor(Color.GRAY);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.log:
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                android.net.NetworkInfo wifi = cm
                        .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                android.net.NetworkInfo datac = cm
                        .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

                if ((wifi != null & datac != null)
                        && (wifi.isConnected() | datac.isConnected())) {
                    login();


                } else {

                    TSnackbar.make(findViewById(android.R.id.content), R.string.no_net, TSnackbar.LENGTH_LONG).show();
                }
                break;

            case R.id.reg1:
                startActivity(new Intent(MainActivity.this, Signup.class));
                break;

            case R.id.textView2:

                ConnectivityManager cm2 = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                android.net.NetworkInfo wifi1 = cm2
                        .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                android.net.NetworkInfo datac1 = cm2
                        .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

                if ((wifi1 != null & datac1 != null)
                        && (wifi1.isConnected() | datac1.isConnected())) {

                    startActivity(new Intent(MainActivity.this, SearchContact.class));

                } else {

                    TSnackbar.make(findViewById(android.R.id.content), R.string.no_net ,TSnackbar.LENGTH_LONG).show();

                }
                break;

            default:
                break;

        }
    }


    private void login() {
        String email = etu.getText().toString().trim();
        String password = etP.getText().toString().trim();

        if (email.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), R.string.pls_fill ,TSnackbar.LENGTH_LONG).show();
        } else if (password.equals("")) {
            TSnackbar.make(findViewById(android.R.id.content), R.string.pls_fill ,TSnackbar.LENGTH_LONG).show();
        } else
            userLogin(email, password);
    }

    private void userLogin(final String email, final String password) {
        class UserLoginClass extends AsyncTask<String, Void, String> {
            private ProgressDialog loading;


            @Override
            protected void onPreExecute() {

                super.onPreExecute();
                loading = ProgressDialog.show(MainActivity.this, "Authenticating...", "Please wait...", true);
                loading.setCancelable(false);
            }

            @Override
            protected String doInBackground(String... params) {
                HashMap<String, String> data = new HashMap<String, String>();

                data.put("email", etu.getText().toString());
                data.put("password", etP.getText().toString());

                Json ruc = new Json();

                String result = ruc.sendPostRequest(LOGIN_URL, data);

                Log.i("DATA ", data.toString());
                Log.i("Post data", result.toString());

                return result;
            }

            @Override
            protected void onPostExecute(String response) {
                super.onPostExecute(response);
                loading.dismiss();

                if (response.equalsIgnoreCase("success")) {

                    //session.setLoggedin(true);

                    Intent intent = new Intent(MainActivity.this, Welcome.class);
                    intent.putExtra(EMAIL, email);
                    Log.i("Email data ", email);
                    Log.i("SERVER_DATA", response);
                    startActivity(intent);
                    MainActivity.this.finish();
                    //Toast.makeText(Login.this, "Welcome back!", Toast.LENGTH_LONG).show();

                } else {
                    TSnackbar.make(findViewById(android.R.id.content), R.string.invalid ,TSnackbar.LENGTH_LONG).show();
                }
            }
        }
        UserLoginClass ulc = new UserLoginClass();
        ulc.execute(email, password);
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Press BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000);
    }
}
