package com.voltamo.appsocket;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;




public class BReceiver extends BroadcastReceiver {


    public void onReceive(Context context, Intent arg1)
    {

        Log.i("FOREGROYUND-----------", "******************************************************");
        SharedPreferences pref = context.getSharedPreferences("LocationTracker", 0);
        int forceStop = pref.getInt("forceStop",1);

        if(forceStop == 0) {
            Intent intent = new Intent(context, LocationService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        }

        Log.i("Autostart", "started");
    }
}
