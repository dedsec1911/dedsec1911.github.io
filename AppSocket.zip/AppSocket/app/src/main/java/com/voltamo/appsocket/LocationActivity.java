package com.voltamo.appsocket;

import android.Manifest;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class LocationActivity extends AppCompatActivity {

	private BroadcastReceiver messageReceiver;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		setTitle("Location Tracker");

		/**
		 * Asking for Runtime Permissions
		 */
		Dexter.withActivity(this)
				.withPermissions(
						Manifest.permission.ACCESS_COARSE_LOCATION,
						//Manifest.permission.ACCESS_NETWORK_STATE,
						Manifest.permission.ACCESS_FINE_LOCATION,
						Manifest.permission.READ_PHONE_STATE,
						Manifest.permission.RECEIVE_BOOT_COMPLETED,
						Manifest.permission.WAKE_LOCK,
						Manifest.permission.FOREGROUND_SERVICE)
				.withListener(new MultiplePermissionsListener() {
					@Override
					public void onPermissionsChecked(MultiplePermissionsReport report) {
						if (!report.areAllPermissionsGranted()) {
							Toast.makeText(LocationActivity.this, "Permission not granted", Toast.LENGTH_LONG).show();
						}
						if (!report.isAnyPermissionPermanentlyDenied()) {
							Toast.makeText(LocationActivity.this, "Permission not granted", Toast.LENGTH_LONG).show();
						}
					}
					@Override
					public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
						token.continuePermissionRequest();
					}
				})
				.onSameThread()
				.check();
		/**
		 * End
		 */

		//Check whether service is running or not.
        boolean started = isMyServiceRunning(LocationService.class);
		Button btnCnct = findViewById(R.id.connect);
        btnCnct.setText(started ? "Stop" : "Start");

		btnCnct.setOnClickListener((View v) -> {

		    boolean isStart  = isMyServiceRunning(LocationService.class);

            SharedPreferences pref = getApplicationContext().getSharedPreferences("LocationTracker", 0);
            SharedPreferences.Editor editor = pref.edit();

			if (!isStart) {
				Intent intent = new Intent(LocationActivity.this, LocationService.class);
                //intent.putExtra("forceStop", 0);
                editor.putInt("forceStop" ,0);
                editor.apply();

                startService(intent);

				btnCnct.setText("Stop");
			} else {
				Intent intent = new Intent(LocationActivity.this, LocationService.class);
                //intent.putExtra("forceStop", 1);
                editor.putInt("forceStop" ,1);
                editor.apply();

				LocationActivity.this.stopService(intent);
				btnCnct.setText("Start");
			}

		});


        final TextView txtResponse = findViewById(R.id.response);
        final List<String> lstMessages = new ArrayList<>();

        IntentFilter intentFilter= new IntentFilter();
        intentFilter.addAction("LogAction");

        messageReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				lstMessages.add(intent.getExtras().getString("message") + '\n');
				String msg = "";
				for(String m : lstMessages){
					msg = m + '\n' + msg;
				}

				txtResponse.setText(msg);

				if(lstMessages.size() > 7) {
					lstMessages.remove(0);
				}
			}
		};

        registerReceiver(messageReceiver, intentFilter);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

		unregisterReceiver(messageReceiver);
	}

	//Configuration Dialog popup
	public void showDialog() {

		final Dialog dialog = new Dialog(this);
		dialog.setContentView(R.layout.dialog_input);
		Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		dialog.setCancelable(false);

		ImageButton cancelBtn = dialog.findViewById(R.id.imgbtn);
		Button acceptBtn = dialog.findViewById(R.id.btnDone);

		//Getting values from Shared Preference
		SharedPreferences pref = getApplicationContext().getSharedPreferences("LocationTracker", 0); // 0 - for private mode

		EditText editHost = dialog.findViewById(R.id.etHost);
		editHost.setText(pref.getString("key_host", Const.DEF_HOST));

		EditText editPort = dialog.findViewById(R.id.etPort);
		editPort.setText(pref.getString("key_port", Const.DEF_PORT));

		EditText editTime = dialog.findViewById(R.id.etTime);
		editTime.setText(pref.getString("key_seconds", Const.DEF_SECONDS));

			cancelBtn.setOnClickListener((View v) -> {
				dialog.dismiss();
			});

			acceptBtn.setOnClickListener((View v) -> {
				String host = editHost.getText().toString();
				String port = editPort.getText().toString();
				String time = editTime.getText().toString();

				if(host == null || host.trim().equals("")) {
				    editHost.setError("Required");
				    return;
                }

                if(port==null || port.trim().equals("")) {
                    editPort.setError("Required");
                    return;
                }

                if(time==null || time.trim().equals("")) {
                    editTime.setError("Required");
                    return;
                }


				SharedPreferences.Editor editor = pref.edit();
				//Saving values to device locally
				editor.putString(Const.HOST_KEY, host);
				editor.putString(Const.PORT_KEY, port);
				editor.putString(Const.SECONDS_KEY, time);
				editor.commit();

				dialog.dismiss();

			});
		dialog.show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu, menu);
		super.onCreateOptionsMenu(menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.item_sett:
				showDialog();
				break;

			default:
				break;
		}
		return super.onOptionsItemSelected(item);
	}

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                Log.i ("isMyServiceRunning?", true+"");
                return true;
            }
        }
        Log.i ("isMyServiceRunning?", false+"");
        return false;
    }
}