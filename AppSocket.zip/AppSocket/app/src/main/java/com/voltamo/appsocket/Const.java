package com.voltamo.appsocket;

public class Const {

    //KEY Values
    public static final String PORT_KEY = "key_port";
    public static final String SECONDS_KEY = "key_seconds";
    public static final String HOST_KEY = "key_host";

    //Default Values
    public static final String DEF_HOST = "192.168.1.109";
    public static final String DEF_PORT = "5555";
    public static final String DEF_SECONDS = "3";

}
