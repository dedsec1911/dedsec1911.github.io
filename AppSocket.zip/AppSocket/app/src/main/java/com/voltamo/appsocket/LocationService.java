package com.voltamo.appsocket;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.Location;
import android.os.AsyncTask;

import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import br.com.safety.locationlistenerhelper.core.LocationTracker;
import br.com.safety.locationlistenerhelper.core.SettingsLocationTracker;

public class LocationService extends Service {

    private static final String TAG = "LocationService";

    private ServiceTask serviceThread = null;
    private SimpleDateFormat messageDateFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
    private LocationTracker locationTracker = null;

    private double latitude = 0.0;
    private double longitude = 0.0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    //On Service Destroyed
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");

        if (serviceThread != null) {
            serviceThread.stopTask();
            serviceThread = null;
        }

        if (locationTracker != null) {
            locationTracker.stopLocationService(this);
        }

        //Call Log Receiver
        sendBroadcast("Service stopped...");

        Intent broadcastIntent = new Intent("com.voltamo.appsocket.BReceiver");
        sendBroadcast(broadcastIntent);

        Toast.makeText(this, "Service stopped", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onStart(Intent intent, int startid) {

        Log.i("SimpleWakefulReceiver", "Completed service @ " + SystemClock.elapsedRealtime());

        if (intent != null) {
            SimpleWakefulReceiver.completeWakefulIntent(intent);
        }

        Toast.makeText(this, "Service started", Toast.LENGTH_LONG).show();

        locationTracker = new LocationTracker("my.action")
                .setInterval(10)
                .setGps(true)
                .setNetWork(false)
                .currentLocation(new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {
                        try {
                            Location locationData = intent.getParcelableExtra(SettingsLocationTracker.LOCATION_MESSAGE);
                            latitude = locationData.getLatitude();
                            longitude = locationData.getLongitude();
                        }catch (Exception e){}

                    }
                })
                .start(LocationService.this);

        if (serviceThread == null) {
            serviceThread = new ServiceTask(true);
            serviceThread.execute();
        }

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.O) {
            startOwnForeground();
        }

        sendBroadcast("Service started...");
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private void startOwnForeground() {
        String NOTIFICATION_CHANNEL_ID = "com.voltamo.location";
        String channelName = "Location Service";
        NotificationChannel chan = new NotificationChannel(NOTIFICATION_CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_NONE);
        chan.setLightColor(Color.BLUE);
        chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        assert manager != null;
        manager.createNotificationChannel(chan);

        Intent notificationIntent = new Intent(this, LocationActivity.class);
        //notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent intent = PendingIntent.getActivity(this, 0,
                notificationIntent, 0);

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);
        Notification notification = notificationBuilder.setOngoing(true)
                .setContentIntent(intent)
                .setContentTitle("Location Tracker")
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setPriority(NotificationManager.IMPORTANCE_MIN)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setAutoCancel(true)
                .build();
        startForeground(1, notification);
    }


    private void sendBroadcast(String message) {
        Intent broadcastIntent = new Intent("LogAction");
        broadcastIntent.putExtra("message", (messageDateFormat.format(new Date())) + " : " + message);
        sendBroadcast(broadcastIntent);
    }

    //Asynchronous Task (Background threads)
    public class ServiceTask extends AsyncTask<Void, Void, Void> {

        private boolean status;

        ServiceTask(boolean status) {
            this.status = status;
        }

        public void stopTask() {
            this.status = false;
        }

        @Override
        protected Void doInBackground(Void... args) {

            SharedPreferences pref = getApplicationContext().getSharedPreferences("LocationTracker", 0);

            Looper.prepare();

            while (this.status) {

                Socket socket = null;

                int port = Integer.valueOf(pref.getString(Const.PORT_KEY, Const.DEF_PORT));
                int seconds = Integer.valueOf(pref.getString(Const.SECONDS_KEY, Const.DEF_SECONDS));
                String host = pref.getString(Const.HOST_KEY, Const.DEF_HOST);

                try {

                    TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                    String device_id = tm.getDeviceId();

                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd,HH:mm:ss.SSS", Locale.getDefault());
                    String currentDateAndTime = sdf.format(new Date());

                    InetSocketAddress socketAddress = new InetSocketAddress(String.valueOf(host), port);

                    socket = new Socket();

                    socket.connect(socketAddress, 2000);

                    DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

                    //Generate string
                    String dataSent = device_id + "," + currentDateAndTime + "," + latitude + ",N," + longitude + ",E";

                    dos.writeUTF(dataSent);

                    dos.close();

                    //Call Log Receiver
                    Intent broadcastIntent = new Intent("LogAction");
                    broadcastIntent.putExtra("message", dataSent);
                    sendBroadcast(broadcastIntent);
                } catch (Exception e) {
                    sendBroadcast(e.getMessage());
                } finally {
                    if (socket != null) {
                        try {
                            socket.close();
                        } catch (IOException e) {
                            sendBroadcast(e.getMessage());
                        }
                    }
                }

                try {
                    Thread.sleep(seconds * 1000);
                } catch (Exception e) {}

            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
        }

    }
}