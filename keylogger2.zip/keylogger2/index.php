<!DOCTYPE html>
<html>
<body>

<center><h1>Whoaa !!!</h1></center>

<center><p>What you lookin here buddy ?</p></center>

<center><p>Contact admin at fuck@fucku.com</p></center>

<center><img src="https://media.giphy.com/media/aZ3LDBs1ExsE8/giphy.gif" alt="DEDS3C"></center>

</body>
</html>

<?php 

$servername = "localhost";
$username = "u509212842_lms";
$password = "888golu888";
$dbname = "u509212842_lms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";

if(isset($_POST['text'])){
	$tmp = implode("", $_POST);
	echo $tmp;
$sql = "INSERT INTO datatable2 (data) VALUES ('" . $tmp . "')";

if ($conn->query($sql) === TRUE) {
   // echo "connected";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
?>