---
name: Feature request
about: Suggest an idea for this project

---

<!--
Please, before submitting, read the "Submitting an issue on GitHub" section in
https://github.com/AnimaRain/ShootAR/blob/master/docs/contributing.md#submitting-an-issue-on-github .

By participating in this project, you are expected to comply with our code of conduct:
https://github.com/AnimaRain/ShootAR/blob/master/docs/code-of-conduct.md
-->

#### Feature description:
*[A clear description of the feature being requested.]*

#### Additional info:
*[Add any other context or images about the feature request, here.]*
