<?php
    $folder_path = "images";

    $extensions = array ('png', 'jpg', 'tif', 'gif'); // add any other extensions to this array

    foreach ($extensions as $extension) {
        foreach (glob ($folder_path . '/*.' . $extension) as $file) {
            if (filectime ($file) < (time () - 2419200)) {
                unlink ($file);
            }
        }
    }
?>

      //$total = 0;
      // List of name of files inside
      // specified folder
      //$files = glob($folder_path.'/*'); 
         
      // Deleting all the files in the list
      //foreach($files as $file) {
         
          //if(is_file($file)) 
          
              // Delete the given file
              //unlink($file); 
              //$total += $file;
        
    //}
    //echo "<script>window.close();</script>";
    //window.location.replace("https://stackoverflow.com/");
    //echo '<script>alert("'.$total.' files deleted successfully.")</script>';
    //echo "<meta http-equiv='refresh' content='0'>";