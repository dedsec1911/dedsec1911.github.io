<?php

    $dir = "../images/";

    $files = glob($dir . "/*.*");
    usort($files, function($a, $b){
        return (filemtime($a) < filemtime($b));
    });

    //$files = array_slice($files, 0, 5);

    foreach($files as $file)
        echo "<img src='" . $file. "' alt='code' height=800px />";

?>